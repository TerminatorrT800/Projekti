﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EkspertniSistem
{
    public partial class Master : Form
    {

        private string tipodabir;
        private int master;
        private string lokacija;
        public Master(string typeChoice, string location)
        {
            tipodabir = typeChoice;
            lokacija = location;

            InitializeComponent();
        }

        private void pitanje_Click(object sender, EventArgs e)
        {
            objasnjenje1.Show();
        }

        private void FormClosedHandler(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void uvodbtnforw_Click(object sender, EventArgs e)
        {
            if (!radioButton1.Checked && !radioButton2.Checked && !radioButton3.Checked)
            {
                MessageBox.Show("Morate odabrati jednu opciju.");
            }
            else if (radioButton1.Checked)
            {
                master = 1;
                Doktor doktor = new Doktor(tipodabir, lokacija, master);
                this.Hide();
                doktor.Show();
            }
            else if (radioButton2.Checked)
            {
                master = 0;
                Cena cena = new Cena(tipodabir, lokacija, master);
                this.Hide();
                cena.Show();
            }
            else
            {
                master = 2;
                Doktor doktor = new Doktor(tipodabir, lokacija, master);
                this.Hide();
                doktor.Show();

            }

        }

        private void uvodbtnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Lokacija lokacijaform = new Lokacija(tipodabir);
            lokacijaform.Show();
        }


    }
}
