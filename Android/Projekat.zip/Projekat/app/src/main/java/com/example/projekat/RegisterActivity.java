package com.example.projekat;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    Button registracija, nazad;

    TextView ime, prezime, email, password;

    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DBHelper(this);

        registracija = findViewById(R.id.btnReg);
        nazad = findViewById(R.id.regNazad);
        ime = findViewById(R.id.ime);
        prezime = findViewById(R.id.prezime);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        registracija.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String IME = ime.getText().toString();
                String PREZIME = prezime.getText().toString();
                String EMAIL = email.getText().toString();
                String PASS = password.getText().toString();
                if (TextUtils.isEmpty(IME) || TextUtils.isEmpty(PREZIME) || TextUtils.isEmpty(EMAIL) || TextUtils.isEmpty(PASS)) {
                    Toast.makeText(RegisterActivity.this, "Sva polja moraju biti popunjena.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(EMAIL).matches()) {
                    Toast.makeText(RegisterActivity.this, "Unesite ispravan e-mail.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (PASS.length() < 6) {
                    Toast.makeText(RegisterActivity.this, "Lozinka mora imati najmanje 6 karaktera.", Toast.LENGTH_SHORT).show();
                    return;
                }

                int vrednost = db.registracija(IME, PREZIME, EMAIL, PASS);
                if(vrednost ==1){
                    Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                    startActivity(intent);
                }

            }
        });

        nazad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}