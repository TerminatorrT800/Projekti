package com.example.projekat;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyVievHolder> {


    private Context context;
    private ArrayList naziv, godizdanja, trajanje, ocena, cena, slika, radnja, filmID;

    private OnItemClickListener onItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    CustomAdapter(Context context, ArrayList naziv, ArrayList godizdanja, ArrayList trajanje, ArrayList ocena, ArrayList cena, ArrayList slika, ArrayList radnja, ArrayList filmID) {
        this.context = context;
        this.naziv = naziv;
        this.godizdanja = godizdanja;
        this.trajanje = trajanje;
        this.ocena = ocena;
        this.cena = cena;
        this.slika = slika;
        this.radnja = radnja;
        this.filmID = filmID;
    }

    @NonNull
    @Override
    public MyVievHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.red_film, parent, false);
        return new MyVievHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyVievHolder holder, int position) {
        holder.nazivTXT.setText(String.valueOf(naziv.get(position)));
        holder.godizdanjaTXT.setText("Godina izdanja: " + String.valueOf(godizdanja.get(position)));
        holder.trajanjeTXT.setText("Trajanje " + String.valueOf(trajanje.get(position)) + "min");
        holder.ocenaTXT.setText("Ocena: " + String.valueOf(ocena.get(position)) + "/10");
        holder.cenaTXT.setText("Cena: " + String.valueOf(cena.get(position)) + "$");
        Glide.with(context).load(slika.get(position)).into(holder.slikaTXT);
        holder.radnjaTXT.setText(String.valueOf(radnja.get(position)));
        holder.filmID.setText(String.valueOf(filmID));

    }

    @Override
    public int getItemCount() {
        return naziv.size();
    }

    public class MyVievHolder extends RecyclerView.ViewHolder {

        TextView nazivTXT, godizdanjaTXT, trajanjeTXT, ocenaTXT, cenaTXT, radnjaTXT, filmID;
        ImageView slikaTXT;

        public MyVievHolder(@NonNull View itemView) {
            super(itemView);
            nazivTXT = itemView.findViewById(R.id.nazivText);
            godizdanjaTXT = itemView.findViewById(R.id.godizdanjaText);
            trajanjeTXT = itemView.findViewById(R.id.trajanjeText);
            ocenaTXT = itemView.findViewById(R.id.ocenaText);
            cenaTXT = itemView.findViewById(R.id.cenaText);
            slikaTXT = itemView.findViewById(R.id.slikaText);
            radnjaTXT = itemView.findViewById(R.id.radnja);
            filmID = itemView.findViewById(R.id.filmID);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onItemClickListener != null) {
                        int position = getAbsoluteAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            onItemClickListener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
