package com.example.projekat;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class PrikazFilmaActivity extends AppCompatActivity {

    FloatingActionButton nazad, korpa, dodajUKorpu;

    TextView naziv, godizdanja, trajanje, ocena, cena, radnja;
    ImageView slika;

    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prikaz_filma);

        Intent intent = getIntent();
        String nazivFilma = intent.getStringExtra("naziv");
        String godinaIzdanja = intent.getStringExtra("godizdanja");
        String trajanjeFilma = intent.getStringExtra("trajanje");
        String ocenaFilma = intent.getStringExtra("ocena");
        String cenaFilma = intent.getStringExtra("cena");
        String slikaFilma = intent.getStringExtra("slika");
        String radnjaFilma = intent.getStringExtra("radnja");
        String filmID = intent.getStringExtra("filmID");

        int korisnikID = intent.getIntExtra("korisnikID", 1);
        String ime = intent.getStringExtra("ime");
        String prezime = intent.getStringExtra("prezime");

        db = new DBHelper(PrikazFilmaActivity.this);

        naziv = findViewById(R.id.naziv);
        naziv.setText(nazivFilma);
        godizdanja = findViewById(R.id.godinaIzdanja);
        godizdanja.setText("Godina izdanja: " + godinaIzdanja);
        trajanje = findViewById(R.id.trajanje);
        trajanje.setText("Trajanje: " + trajanjeFilma + "min");
        ocena = findViewById(R.id.ocena);
        ocena.setText("Ocena: " + ocenaFilma + "/10");
        cena = findViewById(R.id.cena);
        cena.setText("Cena: " + cenaFilma + "$");
        slika = findViewById(R.id.slika);
        Glide.with(this).load(slikaFilma).into(slika);
        radnja = findViewById(R.id.radnja2);
        radnja.setText(radnjaFilma);
        radnja.setMovementMethod(new ScrollingMovementMethod());

        nazad = findViewById(R.id.nazadBTN2);
        korpa = findViewById(R.id.korpa2);
        dodajUKorpu = findViewById(R.id.dodajUKorpu);

        nazad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PrikazFilmaActivity.this, Pocetna.class);
                intent.putExtra("korisnikID", korisnikID);
                intent.putExtra("ime", ime);
                intent.putExtra("prezime", prezime);
                startActivity(intent);
            }
        });

        korpa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PrikazFilmaActivity.this, KorpaActivity.class);
                intent.putExtra("korisnikID", korisnikID);
                intent.putExtra("ime", ime);
                intent.putExtra("prezime", prezime);
                intent.putExtra("filmID", filmID);
                startActivity(intent);

            }
        });

        dodajUKorpu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int parsiranFilmID = Integer.parseInt(filmID);
                    int parsiranaCenaFilma = Integer.parseInt(cenaFilma);
                    db.dodajUKorpu(parsiranFilmID, korisnikID, parsiranaCenaFilma);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    // Handle error, notify user, or log the issue
                    Toast.makeText(PrikazFilmaActivity.this, "Greška pri parsiranju brojeva.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}