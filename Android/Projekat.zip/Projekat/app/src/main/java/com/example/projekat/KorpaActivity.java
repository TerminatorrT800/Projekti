package com.example.projekat;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class KorpaActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton nazad;
    DBHelper db;
    TextView ukupnaCena, header;
    CustomAdapterKorpa customAdapterKorpa;
    ArrayList<String> naziv, cena, slika;

    int korisnikId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_korpa);

        Intent intent = getIntent();
        String ime = intent.getStringExtra("ime");
        String prezime = intent.getStringExtra("prezime");
        korisnikId = intent.getIntExtra("korisnikID", 1);

        nazad = findViewById(R.id.nazadBTN);
        recyclerView = findViewById(R.id.recycleViewKorpa);
        ukupnaCena = findViewById(R.id.ukupnaCena);
        header = findViewById(R.id.header);

        db = new DBHelper(KorpaActivity.this);

        header.setText("Vlasnik korpe: " + ime + " " + prezime);
        int suma = db.ukupnaCena(korisnikId);
        ukupnaCena.setText("Ukupna cena: " + String.valueOf(suma) + "$");

        naziv = new ArrayList<>();
        cena = new ArrayList<>();
        slika = new ArrayList<>();

        customAdapterKorpa = new CustomAdapterKorpa(KorpaActivity.this, naziv, slika, cena, korisnikId, db, ukupnaCena);
        recyclerView.setAdapter(customAdapterKorpa);
        recyclerView.setLayoutManager(new LinearLayoutManager(KorpaActivity.this));

        prikazKorpe();
        nazad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(KorpaActivity.this, Pocetna.class);
                intent.putExtra("ime", ime);
                intent.putExtra("prezime", prezime);
                intent.putExtra("korisnikID", korisnikId);
                startActivity(intent);

            }
        });
    }


    void prikazKorpe() {
        Cursor cursor = db.prikazStavkiKorpe(korisnikId);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                naziv.add(cursor.getString(1));
                cena.add(cursor.getString(5));
                slika.add(cursor.getString(6));
            } while (cursor.moveToNext());
            cursor.close();
        } else {
            Toast.makeText(this, "Nema filmova!", Toast.LENGTH_SHORT).show();
        }
        customAdapterKorpa.notifyDataSetChanged();
    }
}

