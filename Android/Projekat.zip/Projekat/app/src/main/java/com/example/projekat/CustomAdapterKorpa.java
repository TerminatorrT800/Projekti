package com.example.projekat;


import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class CustomAdapterKorpa extends RecyclerView.Adapter<CustomAdapterKorpa.MyViewHolderKorpa> {


    private Context context;

    private ArrayList naziv, slika, cena;

    DBHelper db;
    int korisnikID;

    TextView cena2;

    CustomAdapterKorpa(Context context, ArrayList naziv, ArrayList slika, ArrayList cena, int korisnikID, DBHelper db, TextView cena2) {
        this.context = context;
        this.naziv = naziv;
        this.slika = slika;
        this.cena = cena;
        this.db = db;
        this.korisnikID = korisnikID;
        this.cena2 = cena2;
    }

    @NonNull
    @Override
    public MyViewHolderKorpa onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.red_film_korpa, parent, false);
        return new MyViewHolderKorpa(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolderKorpa holder, int position) {
        String trenutni = String.valueOf(naziv.get(position));
        holder.nazivKorpa.setText(String.valueOf(naziv.get(position)));
        holder.cenaKorpa.setText("Cena: " + String.valueOf(cena.get(position)) + "$");
        Glide.with(context).load(slika.get(position)).into(holder.slikaKorpa);
        holder.ukloni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    int id = db.vratiID(trenutni);
                    db.ukloniIzKorpe(korisnikID, id);
                    int cena = db.ukupnaCena(korisnikID);
                    cena2.setText("Ukupna cena: " + String.valueOf(cena) + "$");

                refreshList();
            }
        });
    }

    @Override
    public int getItemCount() {
        return naziv.size();
    }

    public class MyViewHolderKorpa extends RecyclerView.ViewHolder {

        TextView nazivKorpa, cenaKorpa;
        ImageView slikaKorpa;
        ImageButton ukloni;
        public MyViewHolderKorpa(@NonNull View itemView) {
            super(itemView);
            nazivKorpa = itemView.findViewById(R.id.naslovKorpa);
            cenaKorpa = itemView.findViewById(R.id.cenaKorpa);
            slikaKorpa = itemView.findViewById(R.id.slikaKorpa);
            ukloni = itemView.findViewById(R.id.ukloni);
        }
    }
    private void refreshList() {
        naziv.clear();
        cena.clear();
        slika.clear();
        Cursor cursor = db.prikazStavkiKorpe(korisnikID);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                naziv.add(cursor.getString(1));
                cena.add(cursor.getString(5));
                slika.add(cursor.getString(6));
            } while (cursor.moveToNext());
            cursor.close();
        } else {
            Toast.makeText(context, "Nema filmova!", Toast.LENGTH_SHORT).show();
        }
        notifyDataSetChanged();
    }

}
