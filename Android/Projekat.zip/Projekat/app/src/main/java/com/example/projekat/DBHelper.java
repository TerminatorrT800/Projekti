package com.example.projekat;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DBHelper {

    public class Korisnik {
        private int korisnikId;
        private String ime;
        private String prezime;

        public Korisnik(int korisnikId, String ime, String prezime) {
            this.korisnikId = korisnikId;
            this.ime = ime;
            this.prezime = prezime;
        }

        public int getKorisnikId() {
            return korisnikId;
        }

        public String getIme() {
            return ime;
        }

        public String getPrezime() {
            return prezime;
        }
    }

    private Context context;
    private static final String DBName = "FilmRent";
    private static final int DBVer = 1;
    //Filma tabela
    public static final String FILM_TABLE_NAME = "film";
    public static final String ID = "id";
    public static final String NAZIV = "naziv";
    public static final String GOD_IZD = "godizdanja";
    public static final String TRAJANJE = "trajanje";
    public static final String OCENA = "ocena";
    public static final String CENA = "cena";
    public static final String SLIKA = "slika";
    //Korisnik tabela
    public static final String KORISNIK_TABLE_NAME = "korisnik";
    public static final String KORISNIK_ID = "id_korisnika";
    public static final String KORISNIK_IME = "ime";
    public static final String KORISNIK_PREZIME = "prezime";
    public static final String KORISNIK_EMAIL = "email";
    public static final String KORISNIK_PASSWORD = "password";

    //Korpa tabela
    public static final String KORPA_TABLE_NAME = "korpa";
    public static final String KORPA_ID = "korpa_id";
    public static final String KORPA_CENA = "cena";
    public static final String KORPA_FILM_ID = "film_id";
    public static final String KORPA_KORISNIK_ID = "korisnik_id";

    public DBHelper(@Nullable Context context) {
        this.context = context;
        copyDatabase(context);
    }


    private void copyDatabase(Context context) {
        try {
            String outFileName = context.getDatabasePath(DBName).getPath();

            if (!new File(outFileName).exists()) {
                InputStream inputStream = context.getAssets().open("databases/" + DBName + ".db");

                OutputStream outputStream = new FileOutputStream(outFileName);

                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }

                outputStream.flush();
                outputStream.close();
                inputStream.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public SQLiteDatabase getWritableDatabase() {
        return SQLiteDatabase.openDatabase(context.getDatabasePath(DBName).getPath(), null, SQLiteDatabase.OPEN_READWRITE);
    }

    public SQLiteDatabase getReadableDatabase() {
        return SQLiteDatabase.openDatabase(context.getDatabasePath(DBName).getPath(), null, SQLiteDatabase.OPEN_READONLY);
    }

    int registracija(String ime, String prezime, String email, String password) {
        int vrednost = -1;
        try (SQLiteDatabase db = getWritableDatabase()) {
            Cursor cursor = db.rawQuery("SELECT * FROM " + KORISNIK_TABLE_NAME + " WHERE " + KORISNIK_EMAIL + "=?", new String[]{email});
            if (cursor.getCount() > 0) {
                Toast.makeText(context, "Korisnik sa datim email-om već postoji!", Toast.LENGTH_SHORT).show();
            } else {
                ContentValues cv = new ContentValues();
                cv.put(KORISNIK_IME, ime);
                cv.put(KORISNIK_PREZIME, prezime);
                cv.put(KORISNIK_EMAIL, email);
                cv.put(KORISNIK_PASSWORD, password);
                long rez = db.insert(KORISNIK_TABLE_NAME, null, cv);
                if (rez == -1) {
                    Toast.makeText(context, "Problem sa registracijom!", Toast.LENGTH_SHORT).show();
                    cursor.close();
                } else {
                    Toast.makeText(context, "Uspesno ste se registrovali!", Toast.LENGTH_SHORT).show();
                    cursor.close();
                    vrednost = 1;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vrednost;
    }

    public Korisnik login(String email, String password) {
        try (SQLiteDatabase db = getWritableDatabase()) {
            Cursor cursor = db.rawQuery("SELECT id_korisnika, ime, prezime FROM korisnik WHERE email = ? AND password = ?", new String[]{email, password});

            if (cursor.moveToFirst() && cursor != null) {
                int korisnikIdIndex = cursor.getColumnIndex("id_korisnika");
                int imeIndex = cursor.getColumnIndex("ime");
                int prezimeIndex = cursor.getColumnIndex("prezime");

                if (korisnikIdIndex != -1 && imeIndex != -1 && prezimeIndex != -1) {
                    int korisnikId = cursor.getInt(korisnikIdIndex);
                    String ime = cursor.getString(imeIndex);
                    String prezime = cursor.getString(prezimeIndex);

                    cursor.close();
                    return new Korisnik(korisnikId, ime, prezime);
                }
                return null;
            } else {
                Toast.makeText(context, "Ne postoji korisnik sa ovom kombinacijom email-a i password-a, potrebno je da se registrujete.", Toast.LENGTH_SHORT).show();
                cursor.close();
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }


    Cursor citajFilm() {
        String query = "SELECT * FROM " + FILM_TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    Cursor prikazStavkiKorpe(int id) {
        String query = "SELECT * FROM " + FILM_TABLE_NAME +
                " JOIN " + KORPA_TABLE_NAME + " ON film.id = korpa.film_id" +
                " JOIN " + KORISNIK_TABLE_NAME + " ON korpa.korisnik_id = korisnik.id_korisnika WHERE korisnik_id = ?";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{String.valueOf(id)});
        }
        return cursor;
    }

    int ukupnaCena(int id) {
        String query = "SELECT SUM(cena) AS suma FROM korpa WHERE korisnik_id = ?";
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = null;
        int suma = 0;

        if (db != null) {
            try {
                cursor = db.rawQuery(query, new String[]{String.valueOf(id)});

                if (cursor.moveToFirst()) {
                    int sumaIndex = cursor.getColumnIndex("suma");
                    suma = cursor.getInt(sumaIndex);
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return suma;
    }

    void dodajUKorpu(int filmID, int korisnikID, int cena) {
        String query = "SELECT * FROM korpa WHERE korisnik_id = ? AND film_id = ?";
        try (SQLiteDatabase db = getWritableDatabase()) {
            Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(korisnikID), String.valueOf(filmID)});
            if (cursor.getCount() > 0) {
                Toast.makeText(context, "Film vam se već nalazi u korpi.", Toast.LENGTH_SHORT).show();
            } else {
                ContentValues cv = new ContentValues();
                cv.put(KORPA_CENA, cena);
                cv.put(KORPA_KORISNIK_ID, korisnikID);
                cv.put(KORPA_FILM_ID, filmID);
                db.insert(KORPA_TABLE_NAME, null, cv);
                Toast.makeText(context, "Film je uspesno dodat u korpi!", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void ukloniIzKorpe(int korisnikID, int filmID){
        try (SQLiteDatabase db = getWritableDatabase()){
            long result  = db.delete(KORPA_TABLE_NAME,"korisnik_id =? AND film_id = ?",new String[]{String.valueOf(korisnikID), String.valueOf(filmID)});
            if (result ==-1){
                Toast.makeText(context, "nesto ne valja", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Film je uspesno uklonjen", Toast.LENGTH_SHORT).show();
            }
        }
    }

    int vratiID(String naziv) {
        int filmID = 1;
        String query = "SELECT id FROM film WHERE naziv = ?";
        try (SQLiteDatabase db = getReadableDatabase()) {
            Cursor cursor = db.rawQuery(query, new String[]{naziv});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst(); // Prebaci se na prvi red rezultata
                int index = cursor.getColumnIndex("id");
                filmID = cursor.getInt(index);
            }
            cursor.close();
        }

        return filmID;
    }

}
