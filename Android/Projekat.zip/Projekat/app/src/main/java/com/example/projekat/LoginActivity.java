package com.example.projekat;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    DBHelper dbHelper;
    Button login, nazad;
    TextView email, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DBHelper(this);


        login = findViewById(R.id.LoginBtn);
        nazad = findViewById(R.id.nazadNaPocetak);
        email = findViewById(R.id.logEmail);
        password = findViewById(R.id.logPass);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (TextUtils.isEmpty(email.getText().toString()) || TextUtils.isEmpty(password.getText().toString())) {
                    Toast.makeText(LoginActivity.this, "Unesite email i password.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
                    Toast.makeText(LoginActivity.this, "Unesite ispravan email.", Toast.LENGTH_SHORT).show();
                    return;
                }

                DBHelper.Korisnik korisnik = dbHelper.login(email.getText().toString(), password.getText().toString());
                if (korisnik != null) {
                    Intent intent = new Intent(LoginActivity.this, Pocetna.class);
                    intent.putExtra("korisnikID", korisnik.getKorisnikId());
                    intent.putExtra("ime", korisnik.getIme());
                    intent.putExtra("prezime", korisnik.getPrezime());
                    startActivity(intent);
                }

            }
        });

        nazad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
