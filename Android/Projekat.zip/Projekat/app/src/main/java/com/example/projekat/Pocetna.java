package com.example.projekat;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class Pocetna extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton korpa, nazad;
    DBHelper db;
    CustomAdapter customAdapter;
    ArrayList<String> naziv, godizdanja, trajanje, ocena, cena, slika, radnja, filmID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pocetna);

        Intent intent = getIntent();
        int korisnikID = intent.getIntExtra("korisnikID", 1);
        String ime = intent.getStringExtra("ime");
        String prezime = intent.getStringExtra("prezime");


        recyclerView = findViewById(R.id.recycleView);
        nazad = findViewById(R.id.nazadBTN);
        korpa = findViewById(R.id.korpa);

        db = new DBHelper(Pocetna.this);
        naziv = new ArrayList<>();
        godizdanja = new ArrayList<>();
        trajanje = new ArrayList<>();
        ocena = new ArrayList<>();
        cena = new ArrayList<>();
        slika = new ArrayList<>();
        radnja = new ArrayList<>();
        filmID = new ArrayList<>();

        customAdapter = new CustomAdapter(Pocetna.this, naziv, godizdanja, trajanje, ocena, cena, slika, radnja, filmID);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(Pocetna.this));

        nazad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Pocetna.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        korpa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Pocetna.this, KorpaActivity.class);
                intent1.putExtra("korisnikID", korisnikID);
                intent1.putExtra("ime", ime);
                intent1.putExtra("prezime", prezime);
                //intent1.putExtra("filmID",filmID.get());
                startActivity(intent1);
            }
        });

        customAdapter.setOnItemClickListener(new CustomAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                // Ovde pozovite sledeći ekran i prenesite podatke o filmu
                Intent intent = new Intent(Pocetna.this, PrikazFilmaActivity.class);
                intent.putExtra("naziv", naziv.get(position));
                intent.putExtra("godizdanja", godizdanja.get(position));
                intent.putExtra("trajanje", trajanje.get(position));
                intent.putExtra("ocena", ocena.get(position));
                intent.putExtra("cena", cena.get(position));
                intent.putExtra("slika", slika.get(position));
                intent.putExtra("radnja", radnja.get(position));
                intent.putExtra("filmID", filmID.get(position));
                intent.putExtra("korisnikID", korisnikID);
                intent.putExtra("ime", ime);
                intent.putExtra("prezime", prezime);
                startActivity(intent);
            }
        });

        prikaz();
    }


    void prikaz() {
        Cursor cursor = db.citajFilm();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "Nema filmova!", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                filmID.add(cursor.getString(0));
                naziv.add(cursor.getString(1));
                godizdanja.add(cursor.getString(2));
                trajanje.add(cursor.getString(3));
                ocena.add(cursor.getString(4));
                cena.add(cursor.getString(5));
                slika.add(cursor.getString(6));
                radnja.add(cursor.getString(7));
            }

            customAdapter.notifyDataSetChanged();
        }
    }

}