﻿namespace EkspertniSistem
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            new Home().Show();
            MessageBox.Show("Napomena!\nBaza podataka nije potpuno napunjena. Program radi ispravno, ali postoji šansa da nakon nekoliko konkretnih odgovora, opcije na sledećim pitanjima mogu biti jednake jedinici. ");
            Application.Run();
            
            

        }
    }
}